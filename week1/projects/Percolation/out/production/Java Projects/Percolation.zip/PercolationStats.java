/**
 * Created by Ryan on 1/9/2017.
 */

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private Percolation perc;
    private int[] openSites;
    private double mean;
    private double stddev;
    private double confidenceLow;
    private double confidenceHigh;
    private int trials;
    private int size;

    public PercolationStats(int s, int t) {
        trials = t;
        size = s;
        openSites = new int[t];
        for (int i = 0; i < trials; i++) {
            perc = new Percolation(size);

            while (!perc.percolates()) {
                int col = randInt(1, size + 1);
                int row = randInt(1, size + 1);

                if (row < 0 || row > this.size || col < 0 || col > this.size)
                    throw new IndexOutOfBoundsException("Illegal parameter value.");

                if (!perc.isOpen(row, col)) {
                    perc.open(row, col);
                }
            }
            openSites[i] = perc.numberOfOpenSites();
        }
        mean = mean();
        stddev = stddev();
        confidenceLow = confidenceLo();
        confidenceHigh = confidenceHi();
        System.out.println("mean                    = " + mean);
        System.out.println("stddev                  = " + stddev);
        System.out.println("95% confidence interval = " + confidenceLow + ", " + confidenceHigh);
    }

    private void go() { }

    public double mean() {
        return StdStats.mean(openSites);
    }

    public double stddev() {
        return StdStats.stddev(openSites);
    }

    public double confidenceLo() {
        double colo = mean - ((1.96 * stddev) / trials);
        return colo;

    }

    public double confidenceHi() {
        double cohi = mean + ((1.96 * stddev) / trials);
        return cohi;
    }

    private int randInt(int min, int max) {
        int randomNum = StdRandom.uniform(min, max);
        return randomNum;

    }

    public static void main(String[] args) {
        int size = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        if (size <= 0 && trials <= 0) {
            throw (new IllegalArgumentException());
        }

        PercolationStats stats = new PercolationStats(size, trials);
        stats.go();

    }
}
